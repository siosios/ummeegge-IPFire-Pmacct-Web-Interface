#!/usr/bin/perl
#===============================================================================
# pmacct.cgi – Simplified Live NetFlow/sFlow Traffic Accounting for IPFire
# Version: 4.2.1
#===============================================================================

use strict;
use warnings;
no warnings 'once';
use CGI qw(:standard);
use CGI::Carp qw(fatalsToBrowser warningsToBrowser);
use JSON::PP qw(encode_json decode_json);
use IPC::Open3;
use Fcntl qw(:flock);
use File::Path qw(make_path);
use Time::HiRes qw(gettimeofday tv_interval);
use Compress::Zlib qw(compress uncompress);

# DEBUG: Log user info at start
warn sprintf("PMACCT START: pid=%d, uid=%d(euid=%d), gid=%d(egid=%d), umask=%04o\n", 
	$$, $<, $>, $(, $), umask());

# IPFire specific includes
require '/var/ipfire/general-functions.pl';
require '/var/ipfire/header.pl';
require '/var/ipfire/lang.pl';
require '/var/ipfire/ids-functions.pl';
require '/var/ipfire/network-functions.pl';
require "${General::swroot}/location-functions.pl";

# ------------------------------------------------------------------------------
# CONSTANTS for better maintainability and performance
# ------------------------------------------------------------------------------
use constant {
	CACHE_TTL          => 60,           # Increased from 30 to 60 seconds
	CACHE_COMPRESS     => 1,            # Enable GZIP compression
	CACHE_MAX_SIZE     => 10_485_760,   # 10MB maximum cache size
	CACHE_MAX_FILES    => 5,            # Maximum number of cache files
	PMACCT_TIMEOUT     => 3,            # Reduced from 10 to 3 seconds
	PIPE_CACHE_TTL     => 60,           # Cache for pipe detection (60s)
	DIR_MODE           => 0750,         # 750 instead of 0777
	FILE_MODE          => 0640,         # 640 instead of 0666
	MAX_JSON_SIZE      => 5_242_880,    # 5MB maximum JSON size
	MAX_ROWS_DISPLAY   => 0,            # 0 = no limit (all rows displayed)
};

# ------------------------------------------------------------------------------
# CONFIGURATION
# ------------------------------------------------------------------------------
our @CACHE_DIRS = (
	'/var/tmp/pmacct_cache',
	'/tmp/pmacct_cache',
);
our $CACHE_DIR = '';
our $MAX_ROWS = 0;

# ------------------------------------------------------------------------------
# LOGGING SYSTEM
# ------------------------------------------------------------------------------
my $errormessage = '';
my $infomessage  = '';
my $warnmessage  = '';

sub log_error   { $errormessage .= "$_[0]\n"; warn "[ERROR] $_[0]"; }
sub log_info    { $infomessage  .= "$_[0]\n"; }
sub log_warning { $warnmessage  .= "$_[0]\n"; warn "[WARN] $_[0]"; }

# For JSON responses
my @json_errors;
sub json_error { 
	push @json_errors, $_[0]; 
	warn "[JSON-ERROR] $_[0]";
}

# ------------------------------------------------------------------------------
# UTILITY FUNCTIONS
# ------------------------------------------------------------------------------
sub escape_html {
	my $text = shift;
	return '' unless defined $text;
	
	$text =~ s/&/&amp;/g;
	$text =~ s/</&lt;/g;
	$text =~ s/>/&gt;/g;
	$text =~ s/"/&quot;/g;
	$text =~ s/'/&#39;/g;
	
	return $text;
}

sub check_pmacct_availability {
	return 1 if -x '/usr/bin/pmacct';
	
	my $error = "pmacct is not installed or not executable at /usr/bin/pmacct";
	log_error($error);
	
	# For JSON responses
	my $q = CGI->new;
	if ($q->param('action') && $q->param('action') eq 'get_data') {
		print $q->header(-type => 'application/json', -charset => 'utf-8');
		print encode_json({
			error => $error,
			headers => ['Error'],
			rows => [],
			error_msg => $error
		});
		exit 0;
	}
	
	return 0;
}

# ------------------------------------------------------------------------------
# CACHE SYSTEM with compression and limits
# ------------------------------------------------------------------------------
{
	my $cache_initialized = 0;
	my $last_cleanup_check = 0;
	
	sub find_writable_cache_dir {
		return $CACHE_DIR if $cache_initialized && $CACHE_DIR;
		
		foreach my $dir (@CACHE_DIRS) {
			unless (-d $dir) {
				eval {
					make_path($dir, { mode => DIR_MODE });
					1;
				} or do {
					my $error = $@ || 'Unknown error';
					json_error("Failed to create $dir: $error");
					next;
				};
			}
			
			# Check/set ownership
			my $uid = $>;  # Effective UID
			my $gid = $);  # Effective GID
			
			if (my @stat = stat($dir)) {
				if ($stat[4] != $uid) {
					unless (chown $uid, $gid, $dir) {
						json_error("Cannot change ownership of $dir: $!");
						next;
					}
				}
			}
			
			# Test if we can write
			my $test_file = "$dir/.write_test_$$";
			if (open(my $fh, '>', $test_file)) {
				print $fh "test\n";
				close $fh;
				
				if (-e $test_file) {
					unlink $test_file;
					$CACHE_DIR = $dir;
					$cache_initialized = 1;
					warn "CACHE DIR SELECTED: $dir (mode: " . sprintf("%04o", DIR_MODE) . ")";
					return 1;
				}
			}
		}
		
		$CACHE_DIR = '.';
		$cache_initialized = 1;
		json_error("WARNING: Using current directory as cache (./) - limited functionality");
		return 0;
	}
	
	sub init_cache_dir {
		return 1 if $cache_initialized;
		return find_writable_cache_dir();
	}
	
	sub cache_cleanup {
		init_cache_dir() or return 0;
		
		# Only run cleanup check every 10 requests
		my $now = time;
		return 0 if $now - $last_cleanup_check < 10;
		$last_cleanup_check = $now;
		
		opendir(my $dh, $CACHE_DIR) or return 0;
		my @files;
		
		while (my $file = readdir($dh)) {
			next unless $file =~ /\.cache(\.gz)?$/;
			my $path = "$CACHE_DIR/$file";
			my @stat = stat($path);
			push @files, {
				path => $path,
				mtime => $stat[9],
				size => $stat[7]
			} if @stat;
		}
		closedir $dh;
		
		return 0 unless @files;
		
		# Sort by mtime (oldest first)
		@files = sort { $a->{mtime} <=> $b->{mtime} } @files;
		
		# Calculate total size
		my $total_size = 0;
		$total_size += $_->{size} for @files;
		
		my $deleted = 0;
		
		# Delete files if limits exceeded
		while (@files > CACHE_MAX_FILES || $total_size > CACHE_MAX_SIZE) {
			my $file = shift @files;
			if (unlink $file->{path}) {
				$total_size -= $file->{size};
				$deleted++;
				warn "CACHE CLEANUP: Deleted $file->{path} (size: $file->{size})";
			}
		}
		
		warn "CACHE CLEANUP: Deleted $deleted files, remaining: " . scalar(@files) 
			if $deleted;
		
		return $deleted;
	}
	
	sub cache_get {
		my ($key, $ttl) = @_;
		
		init_cache_dir() or return;
		my $cache_file = "$CACHE_DIR/$key.cache";
		my $compressed = 0;
		
		# Check for compressed file
		if (CACHE_COMPRESS && -f "$cache_file.gz") {
			$cache_file .= '.gz';
			$compressed = 1;
		} elsif (!-f $cache_file) {
			# File doesn't exist
			return;
		}
		
		return unless -f $cache_file;
		
		# Check TTL
		if ($ttl && (time - (stat($cache_file))[9]) > $ttl) {
			unlink $cache_file;
			warn "CACHE GET $key: Expired, deleted";
			return;
		}
		
		if (open(my $fh, '<', $cache_file)) {
			flock($fh, LOCK_SH);
			my $data = do { local $/; <$fh> };
			flock($fh, LOCK_UN);
			close $fh;
			
			# Decompress if needed
			if ($compressed) {
				$data = uncompress($data);
				unless ($data) {
					warn "CACHE GET $key: Decompression failed";
					unlink $cache_file;
					return;
				}
			}
			
			my $decoded = eval { decode_json($data) };
			if ($@) {
				warn "CACHE GET $key: JSON decode failed: $@";
				unlink $cache_file;
				return;
			}
			
			warn "CACHE GET $key: Success (compressed: $compressed, size: " . length($data) . " bytes)";
			return $decoded;
		}
		
		warn "CACHE GET $key: Failed to open file";
		return;
	}
	
	sub cache_set {
		my ($key, $data) = @_;
		
		return 0 unless defined $data;
		
		init_cache_dir() or return 0;
		
		# Remove old files (both compressed and uncompressed)
		my $base_file = "$CACHE_DIR/$key.cache";
		unlink $base_file if -e $base_file;
		unlink "$base_file.gz" if -e "$base_file.gz";
		
		my $cache_file = $base_file;
		
		# Serialize to JSON
		my $json;
		eval {
			$json = encode_json($data);
			1;
		} or do {
			my $error = $@ || 'Unknown error';
			warn "CACHE SET $key: JSON encode failed: $error";
			return 0;
		};
		
		return 0 unless $json;
		
		my $original_size = length($json);
		warn "CACHE SET $key: Original size = $original_size bytes";
		
		# Check size limit
		if ($original_size > MAX_JSON_SIZE) {
			warn "CACHE SET $key: Too large ($original_size > " . MAX_JSON_SIZE . "), not caching";
			return 0;
		}
		
		# Compress if enabled
		my $compressed = 0;
		if (CACHE_COMPRESS) {
			my $compressed_json = eval { compress($json) };
			if ($compressed_json) {
				$json = $compressed_json;
				$cache_file .= '.gz';
				$compressed = 1;
				my $ratio = int(100 * length($json) / $original_size);
				warn "CACHE SET $key: Compressed to " . length($json) . " bytes ($ratio%)";
			} else {
				warn "CACHE SET $key: Compression failed: $@";
			}
		}
		
		if (open(my $fh, '>', $cache_file)) {
			flock($fh, LOCK_EX);
			print $fh $json;
			flock($fh, LOCK_UN);
			close $fh;
			
			chmod FILE_MODE, $cache_file;
			warn "CACHE SET $key: Written to $cache_file";
			
			# Cache cleanup occasionally
			cache_cleanup() if rand() < 0.1;
			
			return 1;
		} else {
			my $error = $!;
			warn "CACHE SET $key: Cannot write file: $error";
			return 0;
		}
	}
	
	sub cache_clear {
		my $count = 0;
		
		init_cache_dir() or return 0;
		
		opendir(my $dh, $CACHE_DIR) or return 0;
		while (my $file = readdir($dh)) {
			next unless $file =~ /\.cache(\.gz)?$/;
			my $path = "$CACHE_DIR/$file";
			if (unlink $path) {
				$count++;
				warn "CACHE CLEAR: Deleted $path";
			}
		}
		closedir $dh;
		
		warn "CACHE CLEAR: Removed $count files";
		return $count;
	}
	
	sub count_cache_files {
		my $count = 0;
		
		init_cache_dir() or return 0;
		
		opendir(my $dh, $CACHE_DIR) or return 0;
		while (my $file = readdir($dh)) {
			$count++ if $file =~ /\.cache(\.gz)?$/;
		}
		closedir $dh;
		
		return $count;
	}
	
	sub get_cache_info {
		init_cache_dir();
		return {
			dir      => $CACHE_DIR,
			ttl      => CACHE_TTL,
			count    => count_cache_files(),
			writable => $cache_initialized ? 1 : 0,
			compressed => CACHE_COMPRESS,
			max_size => CACHE_MAX_SIZE,
			max_files => CACHE_MAX_FILES,
			dir_mode => sprintf("%04o", DIR_MODE),
			file_mode => sprintf("%04o", FILE_MODE),
		};
	}
}

# ------------------------------------------------------------------------------
# NETWORK ZONE COLOR MAPPING with single initialization
# ------------------------------------------------------------------------------
{
	my %networks_cache;
	my @sorted_networks_cache;
	my %zone_cache;
	my $networks_initialized = 0;
	
	sub init_networks_cache {
		return if $networks_initialized;
		
		my %mainsettings = ();
		&General::readhash("/var/ipfire/ethernet/settings", \%mainsettings);
		
		my %networks = (
			"127.0.0.0/8" => ${Header::colourfw},
			"224.0.0.0/4" => "#A0A0A0",
		);
		
		if ($mainsettings{'GREEN_NETADDRESS'}) {
			$networks{"$mainsettings{'GREEN_NETADDRESS'}/$mainsettings{'GREEN_NETMASK'}"} = ${Header::colourgreen};
		}
		if ($mainsettings{'BLUE_NETADDRESS'}) {
			$networks{"$mainsettings{'BLUE_NETADDRESS'}/$mainsettings{'BLUE_NETMASK'}"} = ${Header::colourblue};
		}
		if ($mainsettings{'ORANGE_NETADDRESS'}) {
			$networks{"$mainsettings{'ORANGE_NETADDRESS'}/$mainsettings{'ORANGE_NETMASK'}"} = ${Header::colourorange};
		}
		
		my $red = &IDS::get_red_address();
		$networks{"${red}/32"} = ${Header::colourfw} if $red;
		foreach my $alias (&IDS::get_aliases()) {
			$networks{"${alias}/32"} = ${Header::colourfw} if $alias;
		}
		
		%networks_cache = %networks;
		@sorted_networks_cache = sort { &Network::get_prefix($b) <=> &Network::get_prefix($a) } keys %networks_cache;
		
		$networks_initialized = 1;
		warn "NETWORKS CACHE INITIALIZED: " . scalar(keys %networks_cache) . " networks";
	}
	
	sub ipcolour_cached {
		my $ip = shift // return ${Header::colourred};
		
		init_networks_cache();
		
		return ${Header::colourred} unless $ip =~ /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
		
		# Cache hit check
		return $zone_cache{$ip} if exists $zone_cache{$ip};
		
		# Check against networks with error handling
		foreach my $net (@sorted_networks_cache) {
			next unless $net;
			
			# Validate subnet
			eval {
				return ${Header::colourred} unless &Network::check_subnet($net);
				1;
			} or next;
			
			if (&Network::ip_address_in_network($ip, $net)) {
				my $color = $networks_cache{$net} || ${Header::colourred};
				$zone_cache{$ip} = $color;
				return $color;
			}
		}
		
		my $color = ${Header::colourred};
		$zone_cache{$ip} = $color;
		return $color;
	}
	
	# Clear zone cache if needed (e.g., on network changes)
	sub clear_zone_cache {
		%zone_cache = ();
		warn "ZONE CACHE CLEARED";
	}
}

# ------------------------------------------------------------------------------
# PMACCT MEMORY PIPES DETECTION with caching
# ------------------------------------------------------------------------------
{
	my %pipes_cache;
	my $last_check = 0;
	
	sub get_pmacct_memory_pipes_cached {
		my $now = time;
		
		# Cache valid for PIPE_CACHE_TTL seconds
		if ($now - $last_check < PIPE_CACHE_TTL && keys %pipes_cache) {
			return \%pipes_cache;
		}
		
		my %pipes = ();
		
		my @pipe_dirs = (
			'/var/spool/pmacct',
			'/tmp',
			'/run/pmacct',
			'/var/run/pmacct',
		);
		
		foreach my $dir (@pipe_dirs) {
			next unless -d $dir;
			if (opendir(my $dh, $dir)) {
				while (my $file = readdir($dh)) {
					next unless $file =~ /\.pipe$/;
					my $pipe = "$dir/$file";
					
					# Check if it's a pipe/socket and readable
					if (-e $pipe && (-p $pipe || -S _) && -r _) {
						my $name = $file;
						$name =~ s/\.pipe$//;
						$pipes{$name} = $pipe;
					}
				}
				closedir $dh;
			}
		}
		
		# If no pipes found, check pmacct config
		unless (keys %pipes) {
			my $conf_file = '/etc/pmacct/pmacct.conf';
			if (-r $conf_file) {
				open(my $fh, '<', $conf_file) or return \%pipes;
				my %found_plugins = ();
				
				while (<$fh>) {
					next if /^\s*[!#]/ || !/\S/;
					
					if (/^\s*plugins:\s*/i) {
						while (/memory\s*\[\s*plugin(\d+)\s*\]/ig) {
							$found_plugins{"plugin$1"} = 1;
						}
						next;
					}
					
					if (/^\s*imt_path\s*\[\s*plugin(\d+)\s*\]\s*:\s*(.+?)\s*$/i) {
						my $plugin_num = $1;
						my $pipe = $2;
						$pipe =~ s/\s+//g;
						my $plugin = "plugin$plugin_num";
						if (exists $found_plugins{$plugin}) {
							$pipes{$plugin} = $pipe;
							delete $found_plugins{$plugin};
						}
					}
				}
				close($fh);
			}
		}
		
		%pipes_cache = %pipes;
		$last_check = $now;
		warn "PIPES CACHE UPDATED: " . (keys %pipes_cache) . " pipes found"
			if keys %pipes_cache;
		
		return \%pipes_cache;
	}
}

# ------------------------------------------------------------------------------
# CGI HANDLER
# ------------------------------------------------------------------------------
my $q = CGI->new;

# Check pmacct availability first
check_pmacct_availability();

# AJAX/JSON endpoints
if ($q->param('action') && $q->param('action') eq 'get_data') {
	print $q->header(-type => 'application/json', -charset => 'utf-8');
	my $data = get_pmacct_data();
	print encode_json($data);
	exit 0;
}

if ($q->param('action') && $q->param('action') eq 'clear_cache') {
	print $q->header(-type => 'application/json', -charset => 'utf-8');
	
	my $count = cache_clear();
	print encode_json({
		success => $count > 0 ? 1 : 0,
		message => $count > 0 ? "Cache cleared successfully" : "No cache files found",
		cleared => $count,
		timestamp => time()
	});
	exit 0;
}

# ------------------------------------------------------------------------------
# GET PMACCT DATA - MAIN FUNCTION with performance monitoring
# ------------------------------------------------------------------------------
sub get_pmacct_data {
	my $t0 = [gettimeofday];  # Start timing
	
	my $selected_plugin = $q->param('plugin') // '';
	
	my $cache_info = get_cache_info();
	my $pipes_hash = get_pmacct_memory_pipes_cached();
	
	my $cache_key = "pmacct_initial";
	my $pipe = undef;
	
	if (keys %$pipes_hash) {
		unless ($selected_plugin && exists $pipes_hash->{$selected_plugin}) {
			$selected_plugin = (sort keys %$pipes_hash)[0];
		}
		$cache_key = "pmacct_$selected_plugin";
		$pipe = $pipes_hash->{$selected_plugin};
	}
	
	# Try cache first
	my $cached = cache_get($cache_key, CACHE_TTL);
	
	if ($cached && ref $cached eq 'HASH') {
		my $elapsed = tv_interval($t0);
		$cached->{cache_status} = 'hit';
		$cached->{cache_info} = $cache_info;
		$cached->{performance} = { cache_hit_time => $elapsed };
		$cached->{constants} = {
			cache_compress => CACHE_COMPRESS,
			cache_ttl => CACHE_TTL,
			max_rows_display => MAX_ROWS_DISPLAY,
			pmacct_timeout => PMACCT_TIMEOUT,
		};
		warn "CACHE HIT for $cache_key ($elapsed seconds)";
		return $cached;
	}
	
	# No pipes found
	unless (keys %$pipes_hash) {
		my $elapsed = tv_interval($t0);
		my $result = {
			headers         => ['No data'],
			rows            => [],
			raw_rows        => [],
			ip_colours      => [],
			bytes_col       => -1,
			src_ip_col      => -1,
			dst_ip_col      => -1,
			proto_col       => -1,
			dst_port_col    => -1,
			src_port_col    => -1,
			packet_col      => -1,
			error_msg       => 'No memory plugins or pipes found.',
			pipes           => [],
			selected_plugin => '',
			cache_status    => 'miss',
			cache_info      => $cache_info,
			timestamp       => time(),
			performance     => { total_time => $elapsed },
			constants       => {
				cache_compress => CACHE_COMPRESS,
				cache_ttl => CACHE_TTL,
				max_rows_display => MAX_ROWS_DISPLAY,
				pmacct_timeout => PMACCT_TIMEOUT,
			}
		};
		
		cache_set($cache_key, $result);
		warn "NO PIPES FOUND ($elapsed seconds)";
		return $result;
	}
	
	my @lines;
	my $error = '';
	my $pmacct_time = 0;
	
	# SECURITY: Validate pipe path to prevent command injection
	if ($pipe) {
		# Validate pipe path
		unless ($pipe =~ m{^[/\w][\w/\.\-]+$}) {
			$error = "Invalid pipe path: $pipe";
		} elsif (!-e $pipe) {
			$error = "Pipe does not exist: $pipe";
		} elsif (!-r $pipe) {
			$error = "Cannot read pipe: $pipe";
		} else {
			my ($in, $out, $err);
			my @cmd = ('/usr/bin/timeout', PMACCT_TIMEOUT, '/usr/bin/pmacct', '-p', $pipe, '-s');
			
			my $pmacct_t0 = [gettimeofday];
			my $pid = open3($in, $out, $err, @cmd);
			
			if (defined $pid) {
				close $in if defined $in;
				@lines = defined $out ? <$out> : ();
				waitpid($pid, 0);
				close $out if defined $out;
				close $err if defined $err;
				$pmacct_time = tv_interval($pmacct_t0);
				
				if ($pmacct_time >= PMACCT_TIMEOUT - 0.5) {
					log_warning("pmacct command nearly timed out ($pmacct_time seconds)");
				}
			} else {
				$error = "Failed to execute pmacct: $!";
			}
		}
	}
	
	my $result;
	my $processing_t0 = [gettimeofday];
	
	if ($error || !@lines) {
		$result = {
			headers         => ['No data'],
			rows            => [],
			raw_rows        => [],
			ip_colours      => [],
			bytes_col       => -1,
			src_ip_col      => -1,
			dst_ip_col      => -1,
			proto_col       => -1,
			dst_port_col    => -1,
			src_port_col    => -1,
			packet_col      => -1,
			error_msg       => $error || 'Pipe is empty or pmacct not running.',
			pipes           => [ map { 
				{ 
					name  => $_,
					value => $_,
					path  => $pipes_hash->{$_} 
				} 
			} sort keys %$pipes_hash ],
			selected_plugin => $selected_plugin,
			cache_status    => 'miss',
			cache_info      => $cache_info,
			timestamp       => time(),
			constants       => {
				cache_compress => CACHE_COMPRESS,
				cache_ttl => CACHE_TTL,
				max_rows_display => MAX_ROWS_DISPLAY,
				pmacct_timeout => PMACCT_TIMEOUT,
			}
		};
	} else {
		# Process header line
		my $header_line = '';
		while (@lines && (!$header_line || $header_line !~ /\S/)) {
			$header_line = shift @lines // '';
		}
		
		if ($header_line && $header_line =~ /\S/) {
			my @headers = split(/\s+/, $header_line);
			
			# Find column indexes
			my ($bytes_col, $src_ip_col, $dst_ip_col, $proto_col, 
				$dst_port_col, $src_port_col, $packet_col) = (-1) x 7;
			
			for my $i (0 .. $#headers) {
				my $header = uc($headers[$i]);
				$bytes_col    = $i if $header eq 'BYTES';
				$src_ip_col   = $i if $headers[$i] =~ /SRC.*(IP|HOST)/i;
				$dst_ip_col   = $i if $headers[$i] =~ /DST.*(IP|HOST)/i;
				$proto_col    = $i if $headers[$i] =~ /PROTO/i;
				$dst_port_col = $i if $headers[$i] =~ /DST.*PORT/i;
				$src_port_col = $i if $headers[$i] =~ /SRC.*PORT/i;
				$packet_col   = $i if $header eq 'PACKETS';
			}
			
			my (@rows, @raw_rows, @ip_colours);
			my $row_count = 0;
			
			# Process data rows
			foreach my $line (@lines) {
				next unless $line =~ /\S/;
				next if $line =~ /^For\s+a\s+total\s+of:/i;
				
				my @fields = grep { /\S/ } split(/\s+/, $line);
				
				# Ensure we have enough fields
				while (@fields < @headers) {
					push @fields, '';
				}
				
				next unless @fields >= 2;
				
				my @raw = @fields;
				my @display = @fields;
				
				# Format bytes if present
				if ($bytes_col >= 0 && $bytes_col < @fields && $fields[$bytes_col] =~ /^\d+$/) {
					$display[$bytes_col] = &General::formatBytes($fields[$bytes_col]);
				}
				
				# Get IP colors
				my $src_colour = ($src_ip_col >= 0 && $src_ip_col < @fields && $fields[$src_ip_col]) 
							   ? ipcolour_cached($fields[$src_ip_col]) : ${Header::colourred};
				my $dst_colour = ($dst_ip_col >= 0 && $dst_ip_col < @fields && $fields[$dst_ip_col]) 
							   ? ipcolour_cached($fields[$dst_ip_col]) : ${Header::colourred};
				
				# HTML escape all fields
				@display = map { escape_html($_) } @display;
				
				push @rows, [@display];
				push @raw_rows, [@raw];
				push @ip_colours, { src => $src_colour, dst => $dst_colour };
				$row_count++;
			}
			
			my $processing_time = tv_interval($processing_t0);
			
			$result = {
				headers         => \@headers,
				rows            => \@rows,
				raw_rows        => \@raw_rows,
				ip_colours      => \@ip_colours,
				bytes_col       => $bytes_col,
				src_ip_col      => $src_ip_col,
				dst_ip_col      => $dst_ip_col,
				proto_col       => $proto_col,
				dst_port_col    => $dst_port_col,
				src_port_col    => $src_port_col,
				packet_col      => $packet_col,
				error_msg       => '',
				pipes           => [ map { 
					{ 
						name  => $_,
						value => $_,
						path  => $pipes_hash->{$_} 
					} 
				} sort keys %$pipes_hash ],
				selected_plugin => $selected_plugin,
				cache_status    => 'miss',
				cache_info      => $cache_info,
				timestamp       => time(),
				performance     => {
					pmacct_time     => $pmacct_time,
					processing_time => $processing_time,
					total_time      => tv_interval($t0),
					rows_processed  => $row_count
				},
				constants       => {
					cache_compress => CACHE_COMPRESS,
					cache_ttl => CACHE_TTL,
					max_rows_display => MAX_ROWS_DISPLAY,
					pmacct_timeout => PMACCT_TIMEOUT,
				}
			};
		} else {
			$result = {
				headers         => ['Error'],
				rows            => [],
				raw_rows        => [],
				ip_colours      => [],
				bytes_col       => -1,
				src_ip_col      => -1,
				dst_ip_col      => -1,
				proto_col       => -1,
				dst_port_col    => -1,
				src_port_col    => -1,
				packet_col      => -1,
				error_msg       => 'Failed to parse pmacct output (no valid header)',
				pipes           => [ map { 
					{ 
						name  => $_,
						value => $_,
						path  => $pipes_hash->{$_} 
					} 
				} sort keys %$pipes_hash ],
				selected_plugin => $selected_plugin,
				cache_status    => 'miss',
				cache_info      => $cache_info,
				timestamp       => time(),
				constants       => {
					cache_compress => CACHE_COMPRESS,
					cache_ttl => CACHE_TTL,
					max_rows_display => MAX_ROWS_DISPLAY,
					pmacct_timeout => PMACCT_TIMEOUT,
				}
			};
		}
	}
	
	# Cache the result
	if (cache_set($cache_key, $result)) {
		$result->{cache_info}{count} = count_cache_files();
		$result->{performance}{cached} = 1 if $result->{performance};
	} else {
		$result->{cache_status} = 'error';
	}
	
	my $total_time = tv_interval($t0);
	warn sprintf("PMACCT DATA LOAD: %.3f seconds, rows: %d, cache: %s",
		$total_time, scalar(@{$result->{rows} || []}), $result->{cache_status});
	
	return $result;
}

# ------------------------------------------------------------------------------
# HTML RENDERING - OPTIMIZED VERSION
# ------------------------------------------------------------------------------
&Header::showhttpheaders();
&Header::openpage('Pmacct Traffic Accounting - Optimized', 1, '');

if ($errormessage) {
	&Header::openbox('100%', 'left', $Lang::tr{'error messages'});
	print "<div class='base'>" . $errormessage . "</div>";
	&Header::closebox();
}

&Header::openbigbox('100%', 'left', '');
&Header::openbox('100%', 'left', 'Pmacct Live Traffic Accounting (Optimized v4.2.1)');

print <<'CSS';
<style>
	/* Base styles */
	.tbl {
		border-collapse: collapse;
		margin-top: 10px;
		width: 100%;
		font-size: 12px;
		background-color: #ffffff;
		table-layout: fixed;
	}
	.tbl th {
		background-color: #e0e0e0;
		padding: 6px 8px;
		text-align: left;
		border: 1px solid #cccccc;
		white-space: nowrap;
		cursor: pointer;
		position: sticky;
		top: 0;
		z-index: 10;
		color: #000000;
		font-weight: bold;
		overflow: hidden;
		text-overflow: ellipsis;
	}
	.tbl td {
		padding: 4px 8px;
		border: 1px solid #cccccc;
		vertical-align: top;
		white-space: nowrap;
		color: #000000;
		overflow: hidden;
		text-overflow: ellipsis;
	}
	.tbl tr:nth-child(even) {
		background-color: #f9f9f9;
	}
	.tbl tr:hover {
		background-color: #f0f0f0;
	}
	
	.tbl td a {
		color: #ffffff;
		font-weight: bold;
		text-decoration: underline;
		text-shadow: 1px 1px 1px rgba(0,0,0,0.5);
	}
	
	/* Control styles */
	.control-label {
		display: block;
		margin-bottom: 3px;
		font-weight: bold;
		font-size: 12px;
		color: #000000;
	}
	.control-input {
		width: 100%;
		box-sizing: border-box;
		padding: 4px;
		font-size: 12px;
		border: 1px solid #cccccc;
		border-radius: 3px;
		background-color: #ffffff;
		color: #000000;
	}
	
	/* Button styles */
	button {
		background-color: #3a7d34;
		color: white;
		border: none;
		padding: 6px 14px;
		cursor: pointer;
		border-radius: 3px;
		font-size: 12px;
		transition: background-color 0.2s;
		font-weight: bold;
	}
	button:hover {
		background-color: #2c5c28;
	}
	button.clear-cache {
		background-color: #d9534f;
		margin-left: 10px;
	}
	button.clear-cache:hover {
		background-color: #c9302c;
	}
	button#exportCsv {
		background-color: #5bc0de;
	}
	button#exportCsv:hover {
		background-color: #31b0d5;
	}
	
	/* Status boxes */
	.status-box {
		display: inline-block;
		padding: 6px 12px;
		border-radius: 3px;
		font-size: 12px;
		font-weight: bold;
		min-width: 120px;
		text-align: center;
	}
	.status-loading {
		background-color: #fff3cd;
		color: #856404;
		border: 1px solid #ffeaa7;
	}
	.status-success {
		background-color: #d4edda;
		color: #155724;
		border: 1px solid #c3e6cb;
	}
	.status-error {
		background-color: #f8d7da;
		color: #721c24;
		border: 1px solid #f5c6cb;
	}
	
	/* Cache status */
	.cache-status {
		display: inline-flex;
		align-items: center;
		gap: 10px;
		margin-top: 5px;
		color: #666666;
		font-size: 11px;
		background: #f8f9fa;
		padding: 8px;
		border-radius: 4px;
		border: 1px solid #e9ecef;
	}
	.cache-hit {
		color: #28a745;
		font-weight: bold;
	}
	.cache-miss {
		color: #dc3545;
		font-weight: bold;
	}
	.cache-idle {
		color: #6c757d;
	}
	
	/* Pagination */
	.pagination {
		margin: 15px 0;
		text-align: center;
		font-size: 12px;
	}
	
	.pagination a {
		display: inline-block;
		padding: 4px 8px;
		margin: 0 2px;
		background: #f8f9fa;
		border: 1px solid #dee2e6;
		border-radius: 3px;
		color: #3a7d34;
		text-decoration: none;
	}
	
	.pagination a:hover {
		background: #e9ecef;
	}
	
	.pagination .current {
		background: #3a7d34;
		color: white;
		border-color: #3a7d34;
	}
	
	/* Alerts */
	.pipe-alert {
		margin: 10px 0;
		padding: 10px;
		background-color: #fff3cd;
		border: 1px solid #ffeaa7;
		border-radius: 4px;
		color: #856404;
		font-size: 12px;
	}
	
	/* Performance info */
	.performance-info {
		font-size: 10px;
		color: #6c757d;
		font-style: italic;
		margin-left: 10px;
	}
	
	/* Scrollable container */
	#tablecontainer {
		overflow-x: auto;
		max-height: 600px;
		border: 1px solid #dee2e6;
		border-radius: 4px;
		margin-top: 10px;
	}
	
	/* Responsive adjustments */
	@media (max-width: 768px) {
		.tbl {
			font-size: 11px;
		}
		.tbl th, .tbl td {
			padding: 3px 5px;
		}
		button {
			padding: 4px 8px;
			font-size: 11px;
		}
	}
</style>
CSS

print <<'HTML';
<!-- Controls Section -->
<div style="margin-bottom: 20px; background: #f8f9fa; padding: 15px; border-radius: 5px;">
	<table width="100%" cellspacing="8" cellpadding="0">
	<tr>
		<td style="width: 250px; vertical-align: top;">
			<div class="control-label">Data Source:</div>
			<select id="pluginSelect" class="control-input">
				<option value="">Loading...</option>
			</select>
		</td>
		<td style="width: 150px; vertical-align: top;">
			<div class="control-label">Live Update:</div>
			<select id="refresh" class="control-input">
				<option value="0">Off</option>
				<option value="10" selected>10 seconds</option>
				<option value="20">20 seconds</option>
				<option value="30">30 seconds</option>
				<option value="60">60 seconds</option>
			</select>
		</td>
		<td style="width: 150px; vertical-align: top;">
			<div class="control-label">Rows per page:</div>
			<select id="pageSize" class="control-input">
				<option value="10">10</option>
				<option value="20">20</option>
				<option value="50" selected>50</option>
				<option value="100">100</option>
				<option value="250">250</option>
				<option value="0">All</option>
			</select>
		</td>
		<td style="width: auto;"></td>
	</tr>
	
	<tr>
		<td colspan="4" style="padding-top: 15px;">
			<div style="display: flex; align-items: center; flex-wrap: wrap; gap: 10px;">
				<button id="manualRefresh" title="Force refresh data">Refresh now</button>
				<button id="exportCsv" title="Export to CSV">Export CSV</button>
				
				<div id="status" class="status-box status-loading">Loading...</div>
				
				<div style="display: flex; align-items: center; gap: 20px;">
					<span id="entryCount" style="font-weight: bold; color: #000000;">0 entries</span>
					<span id="lastUpdated" style="font-style: italic; color: #666666;">
						updated at 00:00:00
					</span>
					<span id="performance" class="performance-info"></span>
				</div>
			</div>
		</td>
	</tr>
	
	<tr>
		<td colspan="4" style="padding-top: 15px;">
			<div class="cache-status">
				<span id="cacheInfo">Cache: initializing...</span>
				<button id="clearCache" class="clear-cache" style="padding: 4px 10px; font-size: 11px;"
						title="Clear all cached data">
					Clear Cache
				</button>
				<span id="cacheStats" style="font-size: 10px; color: #6c757d;"></span>
			</div>
		</td>
	</tr>
	</table>
</div>

<!-- Search Row -->
<div style="margin-bottom: 15px;">
	<div class="control-label">Search:</div>
	<div style="display: flex; align-items: center;">
		<select id="searchColumn" style="width: 200px; margin-right: 10px;" class="control-input">
			<option value="-1">All columns</option>
		</select>
		<input type="text" id="search" style="flex: 1;" class="control-input"
			   placeholder="Search in table..." title="Search in current data" />
	</div>
</div>

<!-- Pipe Alert -->
<div id="pipeAlert" class="pipe-alert" style="display: none;"></div>

<!-- Performance Info -->
<div id="performanceInfo" style="font-size: 11px; color: #6c757d; margin: 5px 0; padding: 5px; 
	 background: #f8f9fa; border-radius: 3px; display: none;">
	<strong>Performance:</strong> <span id="perfDetails"></span>
</div>

<!-- Pagination -->
<div id="pagination" class="pagination"></div>

<!-- Table Container -->
<div id="tablecontainer"></div>

<!-- Info Footer -->
<div style="margin-top: 15px; font-size: 11px; color: #6c757d; text-align: center; padding: 10px; 
	 border-top: 1px solid #dee2e6;">
	<strong>Optimized Pmacct Viewer v4.2.1</strong> | 
	Caching: <span id="cacheState">enabled</span> | 
	Compression: <span id="compressionState">enabled</span> |
	Max rows: <span id="maxRows">unlimited</span>
</div>
HTML

print "<script src='/include/jquery.js'></script>";

print <<'JAVASCRIPT';
<script>
// =============================================================================
// PMACCT JavaScript - OPTIMIZED VERSION
// =============================================================================

let refreshInterval = null;
let currentSortCol = null;
let currentSortAsc = false;
let lastSearchTerm = '';
let lastSearchCol = '-1';
let rawData = [];
let allRows = [];
let currentPage = 1;
let pageSize = 50;
let tableMeta = null;
let lastLoadTime = 0;
let loadInProgress = false;

// Utility Functions
function escHtml(s) {
	if (s === null || s === undefined) return '';
	const div = document.createElement('div');
	div.textContent = s;
	return div.innerHTML;
}

function debounce(func, wait) {
	let timeout;
	return function executedFunction(...args) {
		const later = () => {
			clearTimeout(timeout);
			func(...args);
		};
		clearTimeout(timeout);
		timeout = setTimeout(later, wait);
	};
}

function formatBytes(bytes, decimals = 2) {
	if (bytes === 0 || bytes === '0') return '0 Bytes';
	const k = 1024;
	const dm = decimals < 0 ? 0 : decimals;
	const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB'];
	const i = Math.floor(Math.log(bytes) / Math.log(k));
	return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

// Table Functions
function sortTable(col) {
	if (col === currentSortCol) {
		currentSortAsc = !currentSortAsc;
	} else {
		currentSortCol = col;
		currentSortAsc = false;
	}
	renderTable();
}

function updatePagination(totalRows) {
	const totalPages = pageSize === 0 ? 1 : Math.max(1, Math.ceil(totalRows / pageSize));
	currentPage = Math.min(currentPage, totalPages) || 1;
	
	if (pageSize === 0 || totalPages <= 1) {
		$('#pagination').empty();
		return;
	}
	
	let pag = '<strong>Page:</strong> ';
	const maxPages = 7;
	let startPage = Math.max(1, currentPage - Math.floor(maxPages / 2));
	let endPage = Math.min(totalPages, startPage + maxPages - 1);
	
	if (endPage - startPage + 1 < maxPages) {
		startPage = Math.max(1, endPage - maxPages + 1);
	}
	
	if (currentPage > 1) {
		pag += '<a href="#" onclick="currentPage=1; renderTable(); return false">&laquo; First</a> ';
		pag += '<a href="#" onclick="currentPage--; renderTable(); return false">&lsaquo; Prev</a> ';
	}
	
	for (let i = startPage; i <= endPage; i++) {
		if (i === currentPage) {
			pag += '<span class="current">' + i + '</span> ';
		} else {
			pag += '<a href="#" onclick="currentPage=' + i + '; renderTable(); return false">' + i + '</a> ';
		}
	}
	
	if (currentPage < totalPages) {
		pag += '<a href="#" onclick="currentPage++; renderTable(); return false">Next &rsaquo;</a> ';
		pag += '<a href="#" onclick="currentPage=' + totalPages + '; renderTable(); return false">Last &raquo;</a>';
	}
	
	$('#pagination').html(pag);
}

function applySearchOnPage() {
	const term = lastSearchTerm.toLowerCase().trim();
	if (term === '') {
		$('#tablecontainer tbody tr').show();
		$('#entryCount').html(allRows.length + ' entries');
		return;
	}
	
	const col = parseInt(lastSearchCol);
	let visibleCount = 0;
	
	$('#tablecontainer tbody tr').each(function() {
		const $row = $(this);
		let show = false;
		
		if (col === -1) {
			// Search all columns
			$row.children('td').each(function() {
				const cellText = $(this).text().toLowerCase();
				if (cellText.includes(term)) {
					show = true;
					return false; // break
				}
			});
		} else {
			// Search specific column
			const cellText = $row.children('td').eq(col).text().toLowerCase();
			show = cellText.includes(term);
		}
		
		if (show) {
			$row.show();
			visibleCount++;
		} else {
			$row.hide();
		}
	});
	
	$('#entryCount').html(visibleCount + ' visible / ' + allRows.length + ' total');
}

function renderTable() {
	const container = $('#tablecontainer');
	
	if (!tableMeta || allRows.length === 0) {
		container.html('<div style="text-align:center;padding:20px;color:#666;"><em>No data available</em></div>');
		$('#pagination').empty();
		return;
	}
	
	// Sort if needed
	if (currentSortCol !== null) {
		allRows.sort((a, b) => {
			let A = rawData[a.idx][currentSortCol] ?? '';
			let B = rawData[b.idx][currentSortCol] ?? '';
			
			// Special handling for IP addresses
			if (currentSortCol === tableMeta.src_ip_col || currentSortCol === tableMeta.dst_ip_col) {
				const ipToNum = ip => {
					if (!ip) return [0,0,0,0];
					const parts = ip.split('.').map(n => parseInt(n, 10));
					while (parts.length < 4) parts.push(0);
					return parts;
				};
				const arrA = ipToNum(A);
				const arrB = ipToNum(B);
				for (let i = 0; i < 4; i++) {
					if (arrA[i] !== arrB[i]) {
						return (arrA[i] - arrB[i]) * (currentSortAsc ? 1 : -1);
					}
				}
				return 0;
			}
			
			// Try numeric comparison first
			const numA = Number(A);
			const numB = Number(B);
			if (!isNaN(numA) && !isNaN(numB)) {
				return (numA - numB) * (currentSortAsc ? 1 : -1);
			}
			
			// String comparison
			return String(A).localeCompare(String(B)) * (currentSortAsc ? 1 : -1);
		});
	}
	
	// Calculate pagination
	const start = pageSize === 0 ? 0 : (currentPage - 1) * pageSize;
	const end = pageSize === 0 ? allRows.length : Math.min(start + pageSize, allRows.length);
	const pageRows = allRows.slice(start, end);
	
	// Build table HTML
	let html = '<table class="tbl"><thead><tr class="tblhead">';
	
	// Headers
	tableMeta.headers.forEach((h, i) => {
		let arrow = '';
		if (i === currentSortCol) {
			arrow = currentSortAsc ? ' ↑' : ' ↓';
		} else if (i === tableMeta.bytes_col && currentSortCol === null) {
			arrow = ' ↓'; // Default sort by bytes
		}
		
		let safeHeader = escHtml(h.replace(/_/g, ' '));
		html += '<th onclick="sortTable(' + i + ')" title="Click to sort"><b>' + safeHeader + '</b>' + arrow + '</th>';
	});
	html += '</tr></thead><tbody>';
	
	// Rows
	pageRows.forEach(rowObj => {
		html += '<tr data-idx="' + rowObj.idx + '">';
		rowObj.cells.forEach((cell, colIdx) => {
			let content = cell || '&nbsp;';
			let bg = '';
			
			// Apply IP coloring
			const ipc = tableMeta.ip_colours[rowObj.idx];
			if (ipc) {
				if (colIdx === tableMeta.src_ip_col && tableMeta.src_ip_col >= 0) bg = ipc.src;
				if (colIdx === tableMeta.dst_ip_col && tableMeta.dst_ip_col >= 0) bg = ipc.dst;
			}
			
			// Make IPs clickable
			if ((colIdx === tableMeta.src_ip_col || colIdx === tableMeta.dst_ip_col) && 
				/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(content)) {
				content = '<a href="/cgi-bin/ipinfo.cgi?ip=' + encodeURIComponent(content) +
						 '" target="_blank" data-ip="' + content + '" title="IP Info">' + content + '</a>';
			}
			
			html += '<td style="background-color:' + bg + '" title="' + escHtml(content) + '">' + content + '</td>';
		});
		html += '</tr>';
	});
	
	html += '</tbody></table>';
	container.html(html);
	
	updatePagination(allRows.length);
	applySearchOnPage();
}

// Main Data Loader
function loadData() {
	if (loadInProgress) {
		console.log('Load already in progress, skipping');
		return;
	}
	
	const now = Date.now();
	if (now - lastLoadTime < 2000) {
		console.log('Too soon since last load, skipping');
		return;
	}
	
	lastLoadTime = now;
	loadInProgress = true;
	
	// Save search state
	lastSearchTerm = $('#search').val().trim();
	lastSearchCol = $('#searchColumn').val();
	
	const selectedPlugin = $('#pluginSelect').val() || '';
	const url = 'pmacct.cgi?action=get_data' + 
				(selectedPlugin ? '&plugin=' + encodeURIComponent(selectedPlugin) : '') +
				'&_=' + now; // Cache busting
	
	$('#status').html('<span class="status-box status-loading">Loading...</span>');
	$('#performanceInfo').hide();
	
	$.ajax({
		url: url,
		type: 'GET',
		dataType: 'json',
		timeout: 10000, // 10 seconds total timeout
	})
	.done(function(data) {
		tableMeta = data;
		rawData = data.raw_rows || [];
		allRows = (data.rows || []).map((row, idx) => ({ idx: idx, cells: row }));
		
		const now = new Date();
		const timeStr = now.toLocaleTimeString();
		
		let statusHtml = '';
		if (data.error_msg) {
			statusHtml = '<span class="status-box status-error">Error: ' + escHtml(data.error_msg) + '</span>';
		} else {
			statusHtml = '<span class="status-box status-success">' + 
						timeStr + ' – ' + (data.rows || []).length + ' entries</span>';
		}
		
		$('#status').html(statusHtml);
		$('#lastUpdated').html('updated at ' + timeStr);
		
		// Update search column dropdown
		const sel = $('#searchColumn');
		if (sel.children().length <= 1 || sel.children().length !== (data.headers || []).length + 1) {
			sel.empty().append('<option value="-1">All columns</option>');
			(data.headers || []).forEach((h, i) => {
				let safeHeader = escHtml(h.replace(/_/g, ' '));
				sel.append('<option value="' + i + '">' + safeHeader + '</option>');
			});
		}
		
		// Restore search state
		$('#search').val(lastSearchTerm);
		$('#searchColumn').val(lastSearchCol);
		
		// Update plugin dropdown
		const pipes = data.pipes || [];
		const pluginSel = $('#pluginSelect');
		if (pipes.length > 0) {
			pluginSel.empty();
			pipes.forEach(p => {
				pluginSel.append('<option value="' + p.value + '">' + p.name + '</option>');
			});
			pluginSel.val(data.selected_plugin || pipes[0].value);
		}
		
		// Apply page size
		pageSize = parseInt($('#pageSize').val()) || 50;
		currentPage = 1;
		
		// Update cache info
		updateCacheInfo(data);
		
		// Update performance info
		if (data.performance) {
			const perf = data.performance;
			let perfHtml = '';
			if (perf.pmacct_time) {
				perfHtml += 'pmacct: ' + perf.pmacct_time.toFixed(2) + 's, ';
			}
			if (perf.processing_time) {
				perfHtml += 'process: ' + perf.processing_time.toFixed(2) + 's, ';
			}
			if (perf.total_time) {
				perfHtml += 'total: ' + perf.total_time.toFixed(2) + 's';
			}
			if (perfHtml) {
				$('#perfDetails').html(perfHtml);
				$('#performanceInfo').show();
			}
		}
		
		// Render table
		renderTable();
		
		// Show alerts if needed
		if (data.error_msg && (data.error_msg.includes('empty') || data.error_msg.includes('no data'))) {
			$('#pipeAlert').show().html('<strong>⚠️ Note:</strong> ' + escHtml(data.error_msg));
		} else {
			$('#pipeAlert').hide();
		}
	})
	.fail(function(xhr, status, error) {
		let errorMsg = error;
		if (xhr.status === 0) {
			errorMsg = 'Network error or timeout';
		} else if (xhr.status === 404) {
			errorMsg = 'Service not found';
		} else if (xhr.status === 500) {
			errorMsg = 'Server error';
		}
		
		$('#status').html('<span class="status-box status-error">Error: ' + errorMsg + '</span>');
		$('#tablecontainer').html('<div style="text-align:center;padding:20px;color:#dc3545;"><strong>Error loading data:</strong> ' + 
								 escHtml(errorMsg) + '</div>');
		$('#cacheInfo').html('<span class="cache-idle">Cache: error loading data</span>');
	})
	.always(function() {
		loadInProgress = false;
	});
}

function updateCacheInfo(data) {
	const cacheInfo = data.cache_info || {};
	const status = data.cache_status || 'unknown';
	const count = cacheInfo.count || 0;
	const constants = data.constants || {};
	const compressed = cacheInfo.compressed || false;
	
	let html = '';
	let cssClass = 'cache-idle';
	
	switch(status) {
		case 'hit':
			cssClass = 'cache-hit';
			html = `Cache: HIT (${count} files)`;
			break;
		case 'miss':
			cssClass = 'cache-miss';
			html = `Cache: MISS (fresh data · ${count} files)`;
			break;
		case 'error':
			cssClass = 'cache-idle';
			html = `Cache: ERROR (${count} files)`;
			break;
		default:
			cssClass = 'cache-idle';
			html = `Cache: ${status} (${count} files)`;
	}
	
	$('#cacheInfo').html('<span class="' + cssClass + '">' + html + '</span>');
	
	// Update cache stats
	if (cacheInfo.max_size) {
		$('#cacheStats').text('TTL: ' + (constants.cache_ttl || 60) + 's, Max: ' + formatBytes(cacheInfo.max_size));
	}
	
	$('#cacheState').text(cacheInfo.writable ? 'enabled' : 'disabled');
	$('#compressionState').text(compressed ? 'enabled' : 'disabled');
	
	// Update max rows display
	if (constants.max_rows_display !== undefined) {
		$('#maxRows').text(constants.max_rows_display === 0 ? 'unlimited' : constants.max_rows_display);
	}
}

function exportToCSV() {
	if (!tableMeta || rawData.length === 0) {
		alert('No data to export');
		return;
	}
	
	try {
		let csv = tableMeta.headers.join(',') + "\r\n";
		rawData.forEach(row => {
			csv += row.map(f => {
				// Escape quotes and wrap in quotes
				const str = (f + '').replace(/"/g, '""');
				return '"' + str + '"';
			}).join(',') + "\r\n";
		});
		
		const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
		const url = URL.createObjectURL(blob);
		const link = document.createElement('a');
		link.setAttribute('href', url);
		
		const dateStr = new Date().toISOString().slice(0,19).replace(/:/g,'-');
		const plugin = $('#pluginSelect').val() || 'pmacct';
		link.setAttribute('download', plugin + '-' + dateStr + '.csv');
		
		link.style.visibility = 'hidden';
		document.body.appendChild(link);
		link.click();
		document.body.removeChild(link);
		
		// Clean up URL object
		setTimeout(() => URL.revokeObjectURL(url), 100);
		
	} catch (err) {
		console.error('Export error:', err);
		alert('Error exporting CSV: ' + err.message);
	}
}

function clearCache() {
	if (!confirm('Clear all cached data?\n\nThis will force a fresh data reload on next request.\nExisting cache files will be deleted.')) {
		return;
	}
	
	$('#cacheInfo').html('<span class="cache-idle">Clearing cache...</span>');
	
	$.ajax({
		url: 'pmacct.cgi?action=clear_cache',
		type: 'POST',
		dataType: 'json',
		timeout: 10000,
	})
	.done(function(response) {
		if (response.success) {
			// Force reload after cache clear
			setTimeout(loadData, 500);
			alert('Cache cleared successfully! ' + response.cleared + ' files removed.');
		} else {
			alert('Failed to clear cache: ' + (response.message || 'Unknown error'));
			$('#cacheInfo').html('<span class="cache-idle">Cache: clear failed</span>');
		}
	})
	.fail(function() {
		alert('Failed to clear cache (request failed).');
		$('#cacheInfo').html('<span class="cache-idle">Cache: request failed</span>');
	});
}

// Initialize
$(document).ready(function() {
	// Set initial values
	$('#pageSize').val('50');
	$('#refresh').val('10');
	
	// Load data after short delay
	setTimeout(loadData, 800);
	
	// Set up auto-refresh
	$('#refresh').trigger('change');
});

// Event Handlers with debouncing
$('#pageSize').on('change', function() { 
	pageSize = parseInt(this.value) || 0; 
	currentPage = 1; 
	renderTable(); 
});

$('#search').on('input', debounce(function(event) { 
	lastSearchTerm = $(event.target).val().trim(); 
	applySearchOnPage(); 
}, 300));

$('#searchColumn').on('change', function(event) { 
	lastSearchCol = $(event.target).val(); 
	applySearchOnPage(); 
});

$('#refresh').on('change', function() {
	clearInterval(refreshInterval);
	const sec = parseInt(this.value);
	if (sec > 0) {
		refreshInterval = setInterval(loadData, sec * 1000);
		console.log('Auto-refresh set to ' + sec + ' seconds');
	} else {
		console.log('Auto-refresh disabled');
	}
});

$('#manualRefresh').on('click', loadData);
$('#exportCsv').on('click', exportToCSV);
$('#pluginSelect').on('change', loadData);
$('#clearCache').on('click', clearCache);

// Handle page unload
window.addEventListener('beforeunload', function() { 
	clearInterval(refreshInterval); 
	console.log('Cleaned up refresh interval');
});

// Keyboard shortcuts
$(document).keydown(function(e) {
	// Ctrl+R or Cmd+R to refresh
	if ((e.ctrlKey || e.metaKey) && e.keyCode === 82) {
		e.preventDefault();
		loadData();
	}
	// Escape to clear search
	if (e.keyCode === 27) {
		$('#search').val('').trigger('input');
	}
});
</script>
JAVASCRIPT

&Header::closebox();
&Header::closebigbox();
&Header::closepage();
exit 0;